
/*****************************************Etiquetado de pines **************************/

#define PUMP_ON_BUTTON D4 //El botón que prende el relé de la bomba de agua está conectado al pin digital D4 (GPIO2)
#define DHTPIN D5 // el sensor de temperatura y humedad  está conectado al Pin digital D5 o GPIO14
#define ONE_WIRE_BUS 5 //el sensor de temperatura de suelo está conectado al Pin digital D1 O GPIO5
#define PUMP_PIN D2 //El relé de la boba de agua está conectado al Pin digital D1 O GPIO4
#define soilMoisterPin A0// el sensor de humedad de suelo está conectado al Pin digital A0
#define soilMoisterVcc D8/*  el sensor de humedad de suelo se alimenta(suministrar 5v) por medio 
del pin digital D8 porque es un sensor de gran consumo*/
#define SENSORS_READ_BUTTON D6   //El botón que actualiza los valores de los sensores está conectado al pin digital D6 (GPIO2)

/******************************************* Definición de las Variables  ******************************************/

/************************** Variables para la conexión a internet *************************/
#define TOKEN  "BBFF-Ts6ARRUPEL4x6wspLNJk8UerEYcMef"  //TOKEN de ubidots
#define ID_1 "5ce98d391d847243b203c566" // variable ID para la bomba de agua

//contraseñas y Wi-Fi SSID
//#define WIFISSID "ManuelAndroid" // Wi-Fi SSID 1
//#define PASSWORD "manuel123" // Wi-Fi password 1
#define WIFISSID "iPhone de Camila" // Wi-Fi SSID 2
#define PASSWORD "camijeje" // Wi-Fi password 2

//#define WIFISSID "UNE_0595" // Wi-Fi SSID 1
//#define PASSWORD "00002442706007" // Wi-Fi password 2


/*********************************** Variables para el sensor de temperatura y humedad DHT11**********************/
#define DHTTYPE DHT11 // el tipo del sensor de temperatura y humedad  es DHT11
float airTemp=0;// Variable que guarda la temperatura del aire en grados centígrados
float airHum=0;// Variable que guarda la humedad del aire (porcentaje)

/*********************************** Variables para el sensor de humedad de suelo YL-69 **************************/
int soilMoister = 0;// Variable que guarda la humedad del suelo (porcentaje)

/*********************************** Variables del sensor de temperatura de suelo DS18B20 **************************/
float soilTemp;// Variable que guarda la temperatura del suelo en grados centígrados

/*********************************** Variables para los relés **************************/
boolean pumpStatus = 0;//variable booleana que guarda el estado de la bomba de agua (1 si está prendida , 0 si está apagada)


/************* Parámetros para el control automático de la bomba de agua*******************/
#define DRY_SOIL      66 // por debajo de  este valor se considera que el suelo está seco
#define WET_SOIL      85 // por encima de este valor se considera que el suelo está húmedo
#define TIME_PUMP_ON  5 // tiempo por el cual la bomba de agua estará prendida (en segundos)

/*****************************  Timers para la lectura de sensores, botones y control de  actuadores *******************/
#define READ_BUTTONS_TM   1L  // tiempo cada cuánto se leen los botones(en segundos)
#define READ_SOIL_TEMP_TM 2L  // tiempo cada cuánto se lee el sensor de temperatura de suelo (en segundos)
#define READ_SOIL_HUM_TM  10L // tiempo cada cuánto se lee el sensor de humedad de suelo (en segundos)
#define READ_AIR_DATA_TM  2L  // tiempo cada cuánto se lee el sensor de temperatura del aire (en segundos)
#define SEND_UP_DATA_TM   10L // tiempo cada cuánto se envían datos a ubidots (en segundos)
#define AUTO_CTRL_TM      20L // tiempo cada cuánto se hace el control automático de la bomba de agua (en segundos)

/***************************** Variables para la muestra de datos *************************/
boolean turnOffOLED = 1;// Booleano que determina si se muestran los datos en el serial
#define SHOW_SET_UP   30 // tiempo  de espera para mostrar los datos
